package com.gulzar.autosender

import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.Settings
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var target: EditText
    private lateinit var msg: EditText
    private lateinit var apps: RadioGroup
    private lateinit var timeBtn: Button
    private lateinit var status: TextView
    private val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, 5); set(Calendar.SECOND, 0) }
    private val fmt = SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault())
    private val prefs by lazy { getSharedPreferences("jobs", MODE_PRIVATE) }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        apps = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            listOf("WhatsApp" to "wa", "Messenger" to "ms", "Instagram" to "ig").forEachIndexed { i, (n, k) ->
                addView(RadioButton(context).apply { text = n; tag = k; id = i + 1 })
            }
            check(1)
        }
        target = EditText(this).apply { hint = "Phone with country code"; inputType = 3 }
        apps.setOnCheckedChangeListener { _, id ->
            target.hint = if (id == 1) "Phone with country code" else "Username"
            target.inputType = if (id == 1) 3 else 1
        }
        msg = EditText(this).apply { hint = "Message"; minLines = 3 }
        timeBtn = btn("") {
            DatePickerDialog(this, { _, y, mo, d ->
                cal.set(y, mo, d)
                TimePickerDialog(this, { _, h, mi ->
                    cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi); cal.set(Calendar.SECOND, 0)
                    timeBtn.text = fmt.format(cal.time)
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        timeBtn.text = fmt.format(cal.time)
        status = TextView(this)
        listOf(
            apps, target,
            btn("Pick contact (WhatsApp)") {
                apps.check(1)
                startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 1)
            },
            msg, timeBtn,
            btn("Schedule") { schedule() },
            btn("1. Enable Accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("2. Battery: allow unrestricted") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            btn("Clear all scheduled") { clearAll() },
            status
        ).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        val u = d?.data ?: return
        contentResolver.query(u, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use {
            if (it.moveToFirst()) {
                var n = it.getString(0).filter { ch -> ch.isDigit() || ch == '+' }.removePrefix("+")
                if (n.length == 10) n = "91$n"   // assumes India for 10-digit numbers
                target.setText(n)
            }
        }
    }

    private fun pi(id: Int, app: String, t: String, m: String) = PendingIntent.getBroadcast(
        this, id,
        Intent(this, AlarmReceiver::class.java).putExtra("id", id).putExtra("app", app).putExtra("t", t).putExtra("m", m),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun schedule() {
        val t = target.text.toString().trim()
        val m = msg.text.toString()
        if (t.isEmpty() || m.isEmpty()) { status.text = "Fill contact and message"; return }
        if (cal.timeInMillis < System.currentTimeMillis()) { status.text = "Pick a future time"; return }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))); return
        }
        val app = apps.findViewById<View>(apps.checkedRadioButtonId).tag as String
        val id = (System.currentTimeMillis() / 1000).toInt()
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(id, app, t, m))
        prefs.edit().putString("$id", "$app | $t | ${fmt.format(cal.time)}").apply()
        refresh()
    }

    private fun clearAll() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        prefs.all.keys.forEach { am.cancel(pi(it.toInt(), "", "", "")) }
        prefs.edit().clear().apply()
        refresh()
    }

    private fun refresh() {
        val warn = if (SendService.inst == null) "⚠ Accessibility service is OFF - auto-send won't work.\n\n" else "✓ Accessibility service ON\n\n"
        status.text = warn + "Scheduled:\n" + prefs.all.values.joinToString("\n").ifEmpty { "none" }
    }
}
