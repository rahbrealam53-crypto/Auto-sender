package com.gulzar.autosender

import android.content.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.getSharedPreferences("jobs", 0).edit().remove("${i.getIntExtra("id", 0)}").apply()
        SendService.inst?.run(
            i.getStringExtra("app") ?: return,
            i.getStringExtra("t") ?: return,
            i.getStringExtra("m") ?: return
        )
    }
}
