package com.gulzar.autosender

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo as N

class SendService : AccessibilityService() {
    companion object { var inst: SendService? = null }

    private val h = Handler(Looper.getMainLooper())
    private var text: String? = null
    private var tries = 0

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    @Suppress("DEPRECATION")
    fun run(app: String, t: String, m: String) {
        (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "autosender:w"
        ).acquire(60000)
        val (uri, pkg) = when (app) {
            "wa" -> "https://wa.me/$t?text=${Uri.encode(m)}" to "com.whatsapp"
            "ms" -> "https://m.me/$t" to "com.facebook.orca"
            else -> "https://ig.me/m/$t" to "com.instagram.android"
        }
        text = if (app == "wa") null else m   // WhatsApp prefills; others we type
        tries = 0
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            h.postDelayed({ tick() }, 4000)
        } catch (e: Exception) { }
    }

    private fun tick() {
        val root = rootInActiveWindow
        if (root != null) {
            text?.let { t ->
                editable(root)?.let { et ->
                    et.performAction(N.ACTION_SET_TEXT, Bundle().apply {
                        putCharSequence(N.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
                    })
                    text = null
                }
            }
            if (text == null) {
                var n = root.findAccessibilityNodeInfosByText("Send").firstOrNull {
                    it.contentDescription?.toString().equals("Send", true) || it.text?.toString().equals("Send", true)
                }
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) { n.performAction(N.ACTION_CLICK); return }
            }
        }
        if (++tries < 15) h.postDelayed({ tick() }, 1500)
    }

    private fun editable(n: N): N? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> editable(c)?.let { return it } }
        return null
    }
}
